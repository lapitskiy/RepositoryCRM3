from django.apps import AppConfig


class ClientConfig(AppConfig):
    name = 'clients'
    verbose_name = 'Клиенты'

