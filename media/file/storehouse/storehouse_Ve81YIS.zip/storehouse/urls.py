from django.urls import path, include
from .views import *

urlpatterns = [
    path('', StorehouseHomeView.as_view(), name='storehouse_home'),
]


