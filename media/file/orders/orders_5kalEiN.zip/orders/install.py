# файл удаляется после установки

PLUGIN_CFG_UPDATE = {
    'orders': {
        'nav_url': 'orders_home',
        'nav_name': 'Заказы'
    }
}

INSTALLED_APPS_NAME = 'orders.apps.OrderConfig'