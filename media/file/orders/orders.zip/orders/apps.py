from django.apps import AppConfig


class OrderConfig(AppConfig):
    name = 'orders'
    verbose_name = 'Заказы'
