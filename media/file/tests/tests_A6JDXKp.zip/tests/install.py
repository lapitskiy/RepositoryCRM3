# файл удаляется после установки

PLUGIN_CFG_UPDATE = {
    'tests': {
        'nav_url': 'tests_home',
        'nav_name': 'Заказы'
    }
}

INSTALLED_APPS_NAME = 'tests.apps.TestsConfig'